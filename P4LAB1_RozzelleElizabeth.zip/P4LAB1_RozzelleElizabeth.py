#Elizabeth Rozzelle
#July 4, 2025
#P4LAB1
#A turtle graphics programs that draws a triangle and a square using loops.


import turtle  # This lets us use the turtle drawing tool

# Set up the screen and turtle
screen = turtle.Screen()
t = turtle.Turtle()

# Draw a square
# A square has 4 sides and each turn is 90 degrees
for side in range(4):
    t.forward(100)  # Move forward
    t.left(90)      # Turn left

# Move turtle to a new spot so shapes don't overlap too much
t.penup()           # Lift the pen (so it doesn't draw)
t.goto(-150, 0)     # Move to a new position
t.pendown()         # Put the pen back down

# Draw a triangle
# A triangle has 3 sides and each turn is 120 degrees
for side in range(3):
    t.forward(100)  # Move forward
    t.left(120)     # Turn left

