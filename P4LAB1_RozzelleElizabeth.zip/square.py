# Elizabeth Rozzelle
# July 4, 2025
# P4LAB1 - Draw a square using turtle graphics

import turtle

screen = turtle.Screen()
t = turtle.Turtle()

# Draw a square
for side in range(4):
    t.forward(100)
    t.left(90)

screen.mainloop()
