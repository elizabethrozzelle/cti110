# Elizabeth Rozzelle
# July 4, 2025
# P4LAB1 - Draw a triangle using turtle graphics

import turtle

screen = turtle.Screen()
t = turtle.Turtle()

# Draw a triangle
for side in range(3):
    t.forward(100)
    t.left(120)

screen.mainloop()
